import { createBrowserRouter } from "react-router";
import { RoleSelector } from "./components/RoleSelector";
import { SystemAdminPanel } from "./components/system-admin/SystemAdminPanel";
import { ManagerPanel } from "./components/manager/ManagerPanel";
import { DriverPanel } from "./components/driver/DriverPanel";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RoleSelector,
  },
  {
    path: "/system-admin",
    Component: SystemAdminPanel,
  },
  {
    path: "/manager",
    Component: ManagerPanel,
  },
  {
    path: "/driver",
    Component: DriverPanel,
  },
]);
