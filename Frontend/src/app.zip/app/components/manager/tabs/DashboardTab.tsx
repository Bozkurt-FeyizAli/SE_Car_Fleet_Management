import React from "react";
import { Users, Truck, Car, ArrowLeftRight, ShoppingCart, CreditCard, TrendingUp, AlertTriangle } from "lucide-react";
import { StatCard } from "../../shared/StatCard";
import { StatusBadge, getStatusVariant, getStatusLabel } from "../../shared/StatusBadge";
import { currentCompany } from "../ManagerPanel";
import { drivers, vehicles, interCompanyRentals, orders, payments, trips } from "../../../data/mockData";

export function DashboardTab() {
  const companyId = currentCompany.id;
  const compDrivers = drivers.filter(d => d.company_id === companyId);
  const compVehicles = vehicles.filter(v => v.company_id === companyId);
  const compRentals = interCompanyRentals.filter(r => r.owner_comp_id === companyId || r.renter_comp_id === companyId);
  const compOrders = orders.filter(o => o.company_id === companyId);
  const compPayments = payments.filter(p => p.company_id === companyId);
  const activeTrips = trips.filter(t => t.status === "in_progress" && compDrivers.some(d => d.id === t.driver_id));

  const totalIncome = compPayments.filter(p => p.payment_type === "incoming").reduce((s, p) => s + p.amount, 0);
  const totalExpense = compPayments.filter(p => p.payment_type === "outgoing").reduce((s, p) => s + p.amount, 0);
  const avgScore = compDrivers.length > 0 ? (compDrivers.reduce((s, d) => s + d.current_score, 0) / compDrivers.length).toFixed(1) : "0";

  return (
    <div className="space-y-6">
      <div>
        <h2>{currentCompany.name}</h2>
        <p className="text-sm text-muted-foreground mt-1">{currentCompany.address} &middot; {currentCompany.phone}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Truck} label="Soforler" value={compDrivers.length} subtext={`${compDrivers.filter(d => d.status === "on_trip").length} seferde`} color="bg-emerald-600" />
        <StatCard icon={Car} label="Araclar" value={compVehicles.length} subtext={`${compVehicles.filter(v => v.status === "in_service").length} gorevde`} color="bg-blue-600" />
        <StatCard icon={TrendingUp} label="Aktif Seferler" value={activeTrips.length} subtext={`Ort. puan: ${avgScore}`} color="bg-violet-600" />
        <StatCard icon={ShoppingCart} label="Siparisler" value={compOrders.length} subtext={`${compOrders.filter(o => o.status === "pending").length} beklemede`} color="bg-orange-600" />
        <StatCard icon={CreditCard} label="Gelir" value={`₺${totalIncome.toLocaleString("tr-TR")}`} color="bg-teal-600" />
        <StatCard icon={CreditCard} label="Gider" value={`₺${totalExpense.toLocaleString("tr-TR")}`} color="bg-red-500" />
        <StatCard icon={ArrowLeftRight} label="Kiralamalar" value={compRentals.filter(r => r.status === "active").length} subtext="aktif" color="bg-cyan-600" />
        <StatCard icon={AlertTriangle} label="Devre Disi Araclar" value={compVehicles.filter(v => v.status === "out_of_service").length} color="bg-amber-600" />
      </div>

      {/* Recent Orders */}
      <div>
        <h3 className="mb-3">Son Siparisler</h3>
        <div className="rounded-lg border border-border divide-y divide-border">
          {compOrders.slice(-4).reverse().map(order => (
            <div key={order.id} className="px-3 sm:px-4 py-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm truncate">{order.order_number} — {order.customer_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{order.pickup_address} → {order.delivery_address}</p>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <span className="text-sm">₺{order.price.toLocaleString("tr-TR")}</span>
                  <StatusBadge label={getStatusLabel(order.status)} variant={getStatusVariant(order.status)} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Driver Scores */}
      <div>
        <h3 className="mb-3">Sofor Puanlari</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {compDrivers.map(d => (
            <div key={d.id} className="p-3 rounded-lg border border-border bg-card flex items-center justify-between">
              <div>
                <p className="text-sm">{d.first_name} {d.last_name}</p>
                <StatusBadge label={getStatusLabel(d.status)} variant={getStatusVariant(d.status)} />
              </div>
              <div className={`text-xl ${d.current_score >= 80 ? "text-emerald-600" : d.current_score >= 60 ? "text-amber-600" : "text-red-600"}`}>
                {d.current_score}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}