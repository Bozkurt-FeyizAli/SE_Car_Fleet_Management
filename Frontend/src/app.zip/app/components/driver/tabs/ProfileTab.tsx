import React from "react";
import { User, Phone, Mail, CreditCard, Calendar, Award, Hash, Building2, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { StatusBadge, getStatusVariant, getStatusLabel } from "../../shared/StatusBadge";
import { currentDriver, driverCompany } from "../DriverPanel";
import { driverLicenses, driverScores, getDepartmentName } from "../../../data/mockData";

function InfoRow({ icon: Icon, label, value }: { icon: any; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 sm:gap-3 py-2">
      <Icon className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
      <span className="text-sm text-muted-foreground min-w-[90px] sm:min-w-[120px] shrink-0">{label}</span>
      <span className="text-sm text-foreground min-w-0 break-words">{value}</span>
    </div>
  );
}

export function ProfileTab() {
  const license = driverLicenses.find(l => l.driver_id === currentDriver.id);
  const scores = driverScores.filter(s => s.driver_id === currentDriver.id);

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-xl">
          {currentDriver.first_name[0]}{currentDriver.last_name[0]}
        </div>
        <div>
          <h2>{currentDriver.first_name} {currentDriver.last_name}</h2>
          <p className="text-sm text-muted-foreground">{driverCompany.name}</p>
          <div className="flex items-center gap-2 mt-1">
            <StatusBadge label={getStatusLabel(currentDriver.status)} variant={getStatusVariant(currentDriver.status)} />
            <span className={`text-sm px-2 py-0.5 rounded-full ${currentDriver.current_score >= 80 ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
              Puan: {currentDriver.current_score}
            </span>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle>Kisisel Bilgiler</CardTitle></CardHeader>
        <CardContent className="divide-y divide-border">
          <InfoRow icon={User} label="Ad Soyad" value={`${currentDriver.first_name} ${currentDriver.last_name}`} />
          <InfoRow icon={Hash} label="TC Kimlik No" value={currentDriver.identity_number} />
          <InfoRow icon={Phone} label="Telefon" value={currentDriver.phone} />
          <InfoRow icon={Mail} label="E-posta" value={currentDriver.email} />
          <InfoRow icon={Calendar} label="Ise Baslama" value={new Date(currentDriver.hire_date).toLocaleDateString("tr-TR")} />
          <InfoRow icon={Building2} label="Departman" value={getDepartmentName(currentDriver.department_id)} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Ehliyet Bilgileri</CardTitle></CardHeader>
        <CardContent className="divide-y divide-border">
          <InfoRow icon={CreditCard} label="Ehliyet No" value={currentDriver.license_number} />
          <InfoRow icon={CreditCard} label="Ehliyet Sinifi" value={currentDriver.license_class} />
          <InfoRow icon={Calendar} label="Son Kullanma" value={license ? new Date(license.expiry_date).toLocaleDateString("tr-TR") : "—"} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Puan Gecmisi</CardTitle></CardHeader>
        <CardContent>
          {scores.length === 0 ? (
            <p className="text-sm text-muted-foreground">Henuz puan gecmisi yok</p>
          ) : (
            <div className="space-y-3">
              {scores.map(s => (
                <div key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div>
                    <p className="text-sm">{s.comment}</p>
                    <p className="text-xs text-muted-foreground">{new Date(s.created_at).toLocaleDateString("tr-TR")}</p>
                  </div>
                  <span className={`text-lg ${s.score_value >= 80 ? "text-emerald-600" : s.score_value >= 60 ? "text-amber-600" : "text-red-600"}`}>
                    {s.score_value}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}