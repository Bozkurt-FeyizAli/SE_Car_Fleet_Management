import React, { useState } from "react";
import {
  Building2, Car, MapPin, Users, Truck, Settings, AlertTriangle, Zap, User,
} from "lucide-react";
import { useNavigate } from "react-router";
import { ProfileTab } from "./tabs/ProfileTab";
import { CompanyTab } from "./tabs/CompanyTab";
import { VehicleTab } from "./tabs/VehicleTab";
import { TripsTab } from "./tabs/TripsTab";
import { DepartmentTab } from "./tabs/DepartmentTab";
import { AccidentReportTab } from "./tabs/AccidentReportTab";
import { QuickActionsTab } from "./tabs/QuickActionsTab";
import { SettingsTab } from "./tabs/SettingsTab";
import { drivers, companies } from "../../data/mockData";

export const CURRENT_DRIVER_ID = 1;
export const currentDriver = drivers.find(d => d.id === CURRENT_DRIVER_ID)!;
export const driverCompany = companies.find(c => c.id === currentDriver.company_id)!;

const tabs = [
  { id: "profile", label: "Profilim", icon: User },
  { id: "company", label: "Sirket", icon: Building2 },
  { id: "vehicle", label: "Arac", icon: Car },
  { id: "trips", label: "Seferler", icon: MapPin },
  { id: "department", label: "Departman", icon: Users },
  { id: "quick", label: "Hizli", icon: Zap },
  { id: "accident", label: "Kaza", icon: AlertTriangle },
  { id: "settings", label: "Ayarlar", icon: Settings },
];

export function DriverPanel() {
  const [activeTab, setActiveTab] = useState("profile");
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-3 sm:px-6 py-3 sm:py-4 sticky top-0 z-40">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <button
              onClick={() => navigate("/")}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0"
            >
              <Truck className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </button>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg truncate">Sofor Paneli</h1>
              <p className="text-xs text-muted-foreground hidden sm:block truncate">
                {currentDriver.first_name} {currentDriver.last_name} &middot; {currentDriver.license_number}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <div className={`text-xs px-2 py-1 rounded-full hidden sm:block ${currentDriver.current_score >= 80 ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
              Puan: {currentDriver.current_score}
            </div>
            <div className={`text-xs px-1.5 py-0.5 rounded-full sm:hidden ${currentDriver.current_score >= 80 ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
              {currentDriver.current_score}
            </div>
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-sm">
              {currentDriver.first_name[0]}{currentDriver.last_name[0]}
            </div>
          </div>
        </div>
      </header>

      {/* Desktop Tab Navigation */}
      <div className="border-b border-border bg-card hidden sm:block">
        <div className="flex overflow-x-auto px-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap text-sm ${
                  activeTab === tab.id ? "border-emerald-600 text-emerald-600" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-3 sm:p-6 pb-20 sm:pb-6">
        {activeTab === "profile" && <ProfileTab />}
        {activeTab === "company" && <CompanyTab />}
        {activeTab === "vehicle" && <VehicleTab />}
        {activeTab === "trips" && <TripsTab />}
        {activeTab === "department" && <DepartmentTab />}
        {activeTab === "quick" && <QuickActionsTab />}
        {activeTab === "accident" && <AccidentReportTab />}
        {activeTab === "settings" && <SettingsTab />}
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
        <div className="flex overflow-x-auto scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 min-w-[48px] flex flex-col items-center gap-0.5 px-1 py-2 transition-colors ${
                  activeTab === tab.id ? "text-emerald-600" : "text-muted-foreground"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[9px] leading-tight text-center whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}